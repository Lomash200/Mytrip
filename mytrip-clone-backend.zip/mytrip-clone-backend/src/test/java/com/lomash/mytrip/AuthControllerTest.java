package com.lomash.mytrip;

public class AuthControllerTest {
}
