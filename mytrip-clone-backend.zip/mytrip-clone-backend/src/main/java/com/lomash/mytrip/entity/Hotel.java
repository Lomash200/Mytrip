package com.lomash.mytrip.entity;

import jakarta.persistence.*;
import lombok.*;
import java.util.List;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Hotel {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private String city;
    private String address;
    private String location;



    private double rating;       // e.g. 4.3
    private int starCategory;    // e.g. 3, 4, 5 star

    @Column(columnDefinition = "TEXT")
    private String description;  // hotel description

    private String imageUrl;     // main hotel image

    @ElementCollection
    private List<String> amenities; // WiFi, Pool, Spa, Gym etc.

    @OneToMany(mappedBy = "hotel", cascade = CascadeType.ALL)
    private List<Room> rooms;
}
