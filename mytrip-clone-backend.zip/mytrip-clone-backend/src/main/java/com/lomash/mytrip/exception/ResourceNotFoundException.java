package com.lomash.mytrip.exception;

public class ResourceNotFoundException {
}
