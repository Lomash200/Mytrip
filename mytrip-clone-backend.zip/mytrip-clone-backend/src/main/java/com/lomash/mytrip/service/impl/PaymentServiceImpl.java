package com.lomash.mytrip.service.impl;

import com.lomash.mytrip.common.ApiResponse;
import com.lomash.mytrip.dto.payment.PaymentRequest;
import com.lomash.mytrip.dto.payment.PaymentResponse;
import com.lomash.mytrip.entity.Booking;
import com.lomash.mytrip.entity.PaymentRecord;
import com.lomash.mytrip.repository.BookingRepository;
import com.lomash.mytrip.repository.PaymentRecordRepository;
import com.lomash.mytrip.service.EmailService;
import com.lomash.mytrip.service.PaymentService;

import com.razorpay.Order;
import com.razorpay.RazorpayClient;
import com.razorpay.Utils;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class PaymentServiceImpl implements PaymentService {

    private final RazorpayClient client;
    private final BookingRepository bookingRepository;
    private final PaymentRecordRepository paymentRecordRepository;
    private final EmailService emailService;

    @Value("${razorpay.webhook.secret}")
    private String webhookSecret;

    public PaymentServiceImpl(
            @Value("${razorpay.key}") String key,
            @Value("${razorpay.secret}") String secret,
            BookingRepository bookingRepository,
            PaymentRecordRepository paymentRecordRepository,
            EmailService emailService
    ) throws Exception {

        this.client = new RazorpayClient(key, secret);
        this.bookingRepository = bookingRepository;
        this.paymentRecordRepository = paymentRecordRepository;
        this.emailService = emailService;
    }

    // ======================================================
    // CREATE ORDER
    // ======================================================
    @Override
    public PaymentResponse createOrder(PaymentRequest request) {

        try {
            Booking booking = bookingRepository.findById(request.getBookingId())
                    .orElse(null);

            if (booking == null) {
                return new PaymentResponse(null, 0, "Booking not found");
            }

            long amountInPaise = (long) (request.getAmount() * 100);

            JSONObject options = new JSONObject();
            options.put("amount", amountInPaise);
            options.put("currency", "INR");
            options.put("receipt", "bkg_" + booking.getId());

            Order order = client.orders.create(options);
            String orderId = order.get("id");

            // Save orderId in DB
            booking.setOrderId(orderId);
            bookingRepository.save(booking);

            return new PaymentResponse(orderId, request.getAmount(), "Order created");

        } catch (Exception e) {
            return new PaymentResponse(null, request.getAmount(), "Failed: " + e.getMessage());
        }
    }

    // ======================================================
    // VERIFY PAYMENT
    // ======================================================
    @Override
    public ApiResponse<String> verifyPayment(String orderId, String paymentId, String signature) {

        try {
            String payload = orderId + "|" + paymentId;

            boolean verified = Utils.verifySignature(payload, signature, webhookSecret);

            if (!verified) {
                return ApiResponse.error("Signature mismatch");
            }

            Booking booking = bookingRepository.findByOrderId(orderId)
                    .orElse(null);

            if (booking == null) {
                return ApiResponse.error("Booking not found");
            }

            // Save payment record
            PaymentRecord record = PaymentRecord.builder()
                    .orderId(orderId)
                    .paymentId(paymentId)
                    .signature(signature)
                    .amount(booking.getTotalAmount())
                    .status("PAID")
                    .booking(booking)
                    .build();

            paymentRecordRepository.save(record);

            // Update booking status
            booking.setPaymentStatus("PAID");
            bookingRepository.save(booking);

            // -------- SAFE ROOM TYPE --------
            String roomType = (booking.getRoom() != null && booking.getRoom().getRoomType() != null)
                    ? booking.getRoom().getRoomType()
                    : "Room";


            // -------- SEND EMAIL --------
            emailService.sendBookingConfirmation(
                    booking.getUser().getEmail(),
                    booking.getReferenceCode(),
                    booking.getHotel().getName(),
                    roomType,
                    booking.getCheckInDate().toString(),
                    booking.getCheckOutDate().toString(),
                    booking.getTotalAmount()
            );

            return ApiResponse.ok("Payment successful", null);

        } catch (Exception e) {
            return ApiResponse.error("Verification failed: " + e.getMessage());
        }
    }
}
