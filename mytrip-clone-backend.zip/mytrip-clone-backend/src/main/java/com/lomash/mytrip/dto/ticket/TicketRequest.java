package com.lomash.mytrip.dto.ticket;

import lombok.Data;

@Data
public class TicketRequest {
    private String subject;
}
