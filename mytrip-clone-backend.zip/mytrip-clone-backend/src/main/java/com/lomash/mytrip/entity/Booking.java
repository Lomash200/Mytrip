package com.lomash.mytrip.entity;

import com.lomash.mytrip.entity.enums.BookingStatus;
import jakarta.persistence.*;
import lombok.*;

import java.time.Instant;
import java.time.LocalDate;
import java.time.Instant;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Booking {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String referenceCode;

    private LocalDate checkInDate;
    private LocalDate checkOutDate;

    private int guests;

    private double totalAmount;
   private Instant reservationExpiresAt;
//    private String orderId;        // Razorpay Order ID
//    private String paymentStatus;  // PENDING_PAYMENT / PAID / FAILED
//    private Instant reservationExpiresAt; // reservation expiry timestamp


    @Enumerated(EnumType.STRING)
    private BookingStatus status;

    @ManyToOne
    private User user;

    @ManyToOne
    private Hotel hotel;

    @ManyToOne
    private Room room;

    // ------------------------------------------
    // 🔥 PAYMENT FIELDS (ADDED)
    // ------------------------------------------

    private String orderId;        // Razorpay Order ID
    private String paymentStatus;  // PENDING / PAID / FAILED

    // ------------------------------------------

    private Instant createdAt;
    private Instant updatedAt;

    @PrePersist
    public void prePersist() {
        Instant now = Instant.now();
        this.createdAt = now;
        this.updatedAt = now;
    }

    @PreUpdate
    public void preUpdate() {
        this.updatedAt = Instant.now();
    }
}
