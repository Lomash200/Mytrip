package com.lomash.mytrip.entity.enums;

public enum KycStatus {
    PENDING,
    APPROVED,
    REJECTED
}
