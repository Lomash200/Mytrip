package com.lomash.mytrip.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Room {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String roomNumber;
    private String roomType;
    private int capacity;
    private double pricePerNight;
    private String description;

    // 🔥 Earlier only 1 imageUrl was present
    private String imageUrl;

    // ==========================
    // ⭐ ADDING FIELDS EXPECTED BY RoomServiceImpl
    // ==========================

    // Max guests allowed (RoomServiceImpl → getMaxGuests()/setMaxGuests)
    private int maxGuests;

    // Available rooms count (RoomServiceImpl → getAvailabilityCount()/setAvailabilityCount)
    private int availabilityCount;

    // Multiple images support (RoomServiceImpl → getImages())
    @ElementCollection
    private java.util.List<String> images;

    @ManyToOne
    private Hotel hotel;
}
