package com.lomash.mytrip.dto.payment;

import lombok.Data;

@Data
public class PaymentRequest {
    private double amount;
    private Long bookingId;   // ADD THIS
}
