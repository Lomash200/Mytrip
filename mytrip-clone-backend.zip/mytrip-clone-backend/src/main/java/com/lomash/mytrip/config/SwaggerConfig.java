package com.lomash.mytrip.config;

public class SwaggerConfig {
}
