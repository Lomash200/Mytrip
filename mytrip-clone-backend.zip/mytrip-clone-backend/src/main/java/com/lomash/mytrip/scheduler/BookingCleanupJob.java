package com.lomash.mytrip.scheduler;

public class BookingCleanupJob {
}
