package com.lomash.mytrip.entity.enums;

public enum WishlistType {
    HOTEL,
    FLIGHT
}
