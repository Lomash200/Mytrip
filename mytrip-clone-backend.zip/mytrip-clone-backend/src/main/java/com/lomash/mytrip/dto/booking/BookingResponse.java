package com.lomash.mytrip.dto.booking;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class BookingResponse {

    private Long bookingId;
    private String referenceCode;

    private Long hotelId;
    private Long roomId;

    private LocalDate checkInDate;
    private LocalDate checkOutDate;

    private int guests;

    // price breakdown
    private double baseAmount;
    private double gstAmount;
    private double serviceFee;
    private double convenienceFee;
    private double finalAmount;

    private String paymentStatus;
    private String message;

    // -----------------------------
    // SUCCESS for creation
    // -----------------------------
    public static BookingResponse success(
            Long bookingId,
            String referenceCode,
            Long hotelId,
            Long roomId,
            LocalDate checkInDate,
            LocalDate checkOutDate,
            int guests,
            double baseAmount,
            double gstAmount,
            double serviceFee,
            double convenienceFee,
            double finalAmount,
            String message
    ) {
        return new BookingResponse(
                bookingId,
                referenceCode,
                hotelId,
                roomId,
                checkInDate,
                checkOutDate,
                guests,
                baseAmount,
                gstAmount,
                serviceFee,
                convenienceFee,
                finalAmount,
                "PENDING_PAYMENT",
                message
        );
    }

    // -----------------------------
    // FAILED response
    // -----------------------------
    public static BookingResponse failed(String message) {
        return new BookingResponse(
                null,
                null,
                null,
                null,
                null,
                null,
                0,
                0,
                0,
                0,
                0,
                0,
                "FAILED",
                message
        );
    }

    // -----------------------------
    // SUCCESS for list/bookings page
    // -----------------------------
    public static BookingResponse successList(
            Long bookingId,
            String referenceCode,
            Long hotelId,
            Long roomId,
            LocalDate checkInDate,
            LocalDate checkOutDate,
            int guests,
            double finalAmount,
            String paymentStatus
    ) {
        return new BookingResponse(
                bookingId,
                referenceCode,
                hotelId,
                roomId,
                checkInDate,
                checkOutDate,
                guests,
                0, 0, 0, 0, finalAmount,
                paymentStatus,
                "OK"
        );
    }
}
