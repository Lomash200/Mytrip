package com.lomash.mytrip.mapper;

public class UserMapper {
}
