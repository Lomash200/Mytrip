package com.lomash.mytrip.entity.enums;

public enum BookingStatus {
    PENDING,
    CONFIRMED,
    CANCELLED
}
