package com.lomash.mytrip.service.impl;

public class AdminServiceImpl {
}
