package com.lomash.mytrip.entity.enums;

public enum FlightBookingStatus {
    PENDING,
    CONFIRMED,
    CANCELLED
}
