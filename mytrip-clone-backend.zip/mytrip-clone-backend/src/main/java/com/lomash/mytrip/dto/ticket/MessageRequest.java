package com.lomash.mytrip.dto.ticket;

import lombok.Data;

@Data
public class MessageRequest {
    private String message;
}
