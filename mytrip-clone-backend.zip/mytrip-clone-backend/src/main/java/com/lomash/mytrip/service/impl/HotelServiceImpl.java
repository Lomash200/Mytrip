package com.lomash.mytrip.service.impl;

import com.lomash.mytrip.dto.hotel.HotelRequest;
import com.lomash.mytrip.dto.hotel.HotelResponse;
import com.lomash.mytrip.entity.Hotel;
import com.lomash.mytrip.entity.Room;
import com.lomash.mytrip.exception.ApiException;
import com.lomash.mytrip.repository.BookingRepository;
import com.lomash.mytrip.repository.HotelRepository;
import com.lomash.mytrip.repository.RoomRepository;
import com.lomash.mytrip.service.HotelService;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class HotelServiceImpl implements HotelService {

    private final HotelRepository hotelRepository;
    private final RoomRepository roomRepository;
    private final BookingRepository bookingRepository;

    public HotelServiceImpl(HotelRepository hotelRepository,
                            RoomRepository roomRepository,
                            BookingRepository bookingRepository) {
        this.hotelRepository = hotelRepository;
        this.roomRepository = roomRepository;
        this.bookingRepository = bookingRepository;
    }

    // -------------------- CREATE HOTEL --------------------
    @Override
    public HotelResponse createHotel(HotelRequest request) {
        Hotel hotel = Hotel.builder()
                .name(request.getName())
                .description(request.getDescription())
                .address(request.getAddress())
                .city(getCityFromLocationId(request.getLocationId()))
                .rating(request.getRating())
                .build();

        hotel = hotelRepository.save(hotel);
        return toResponse(hotel);
    }

    // -------------------- UPDATE HOTEL --------------------
    @Override
    public HotelResponse updateHotel(Long id, HotelRequest request) {
        Hotel hotel = hotelRepository.findById(id)
                .orElseThrow(() -> new ApiException("Hotel not found"));

        hotel.setName(request.getName());
        hotel.setDescription(request.getDescription());
        hotel.setAddress(request.getAddress());
        hotel.setCity(getCityFromLocationId(request.getLocationId()));
        hotel.setRating(request.getRating());

        hotelRepository.save(hotel);
        return toResponse(hotel);
    }

    // -------------------- DELETE HOTEL --------------------
    @Override
    public void deleteHotel(Long id) {
        hotelRepository.deleteById(id);
    }

    // -------------------- GET HOTEL BY ID --------------------
    @Override
    public HotelResponse getHotelById(Long id) {
        Hotel hotel = hotelRepository.findById(id)
                .orElseThrow(() -> new ApiException("Hotel not found"));
        return toResponse(hotel);
    }

    // -------------------- PAGINATION --------------------
    @Override
    public Page<HotelResponse> getAllHotels(int page, int size) {
        PageRequest pageable = PageRequest.of(page, size);
        Page<Hotel> hotels = hotelRepository.findAll(pageable);

        List<HotelResponse> dtoList = hotels.getContent()
                .stream()
                .map(this::toResponse)
                .toList();

        return new PageImpl<>(dtoList, pageable, hotels.getTotalElements());
    }

    // -------------------- ADD HOTEL IMAGE --------------------
    @Override
    public void addHotelImage(Long hotelId, String imageUrl) {
        Hotel hotel = hotelRepository.findById(hotelId)
                .orElseThrow(() -> new ApiException("Hotel not found"));

        hotel.setImageUrl(imageUrl);
        hotelRepository.save(hotel);
    }

    // -------------------- SEARCH HOTELS --------------------
    @Override
    public List<Hotel> searchHotels(String city, String name, Double minPrice, Double maxPrice) {

        List<Hotel> hotels;

        if (city != null && !city.isBlank()) {
            hotels = hotelRepository.findByCityIgnoreCase(city);
        } else if (name != null && !name.isBlank()) {
            hotels = hotelRepository.findByNameContainingIgnoreCase(name);
        } else {
            hotels = hotelRepository.findAll();
        }

        if (minPrice != null || maxPrice != null) {
            double min = (minPrice == null) ? Double.MIN_VALUE : minPrice;
            double max = (maxPrice == null) ? Double.MAX_VALUE : maxPrice;

            return hotels.stream().filter(h ->
                    h.getRooms() != null &&
                            h.getRooms().stream().anyMatch(r ->
                                    r.getPricePerNight() >= min &&
                                            r.getPricePerNight() <= max
                            )
            ).collect(Collectors.toList());
        }

        return hotels;
    }

    // -------------------- GET HOTEL ENTITY --------------------
    @Override
    public Hotel getHotel(Long hotelId) {
        return hotelRepository.findById(hotelId).orElse(null);
    }

    // -------------------- GET ROOMS --------------------
    @Override
    public List<Room> getRoomsForHotel(Long hotelId) {
        return roomRepository.findByHotelId(hotelId);
    }

    // -------------------- CHECK AVAILABILITY --------------------
    @Override
    public boolean isRoomAvailable(Long roomId, LocalDate checkIn, LocalDate checkOut) {
        List bookings =
                bookingRepository.findByRoomIdAndCheckOutDateGreaterThanAndCheckInDateLessThan(
                        roomId, checkIn, checkOut);

        return bookings == null || bookings.isEmpty();
    }


    // ==========================================================
    //  HELPER → MAP ENTITY TO RESPONSE DTO
    // ==========================================================
    private HotelResponse toResponse(Hotel h) {
        if (h == null) return null;

        return HotelResponse.builder()
                .id(h.getId())
                .name(h.getName())
                .description(h.getDescription())
                .address(h.getAddress())
                .locationName(h.getCity())   // your DTO expects "locationName"
                .rating(h.getRating())
                .build();
    }

    // ==========================================================
    //  HELPER → Map locationId → city name
    //  (TEMP LOGIC — UPDATE IF NEEDED)
    // ==========================================================
    private String getCityFromLocationId(Long locationId) {
        if (locationId == null) return null;

        // You can replace this with real logic (fetch from table)
        return "City-" + locationId; // temporary safe mapping
    }
}
